import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'STR', total: 19, closed: 14 },
  { name: 'FIN', total: 7, closed: 6 },
  { name: 'QLT', total: 9, closed: 8 },
  { name: 'MAN', total: 15, closed: 15 },
  { name: 'STO', total: 5, closed: 5 },
  { name: 'HR', total: 10, closed: 9 },
];

const Chart1 = () => {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={data}>
        <XAxis dataKey="name" />
        <YAxis />
        <CartesianGrid stroke="#f5f5f5" />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="total" stroke="#007bff" activeDot={{ r: 8 }} />
        <Line type="monotone" dataKey="closed" stroke="#5cb85c" activeDot={{ r: 8 }} />
      </LineChart>
    </ResponsiveContainer>
  );
};

export default Chart1;