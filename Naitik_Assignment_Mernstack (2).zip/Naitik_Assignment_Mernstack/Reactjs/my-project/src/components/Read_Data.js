import React, { useEffect, useState } from 'react';
import './Read.css'; // Import your CSS file
import Logo from './Logo.svg';
import DashboardHeader from './DashboardHeader';
import ReactPaginate from 'react-paginate';

const Api = 'http://localhost:4000/getdata';

const Read = () => {
  const [users, setUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(0);
  const [usersPerPage] = useState(10); // Changed from 5 to 10

  const fetchProject = async (url) => {
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const result = await response.json();

      // Check if the fetched data has a data property that is an array
      if (result.success && Array.isArray(result.data)) {
        setUsers(result.data);
      } else {
        console.error("Fetched data is not an array:", result);
        setUsers([]); // Setting users to an empty array if data is not an array
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const updateStatus = async (id) => {
    try {
      const response = await fetch(`http://localhost:4000/updatestatus/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      const result = await response.json();
      console.log("id is the", id)
      if (result.success) {
        // Update the local state to reflect the new status
        console.log("data updated successfully");
      } else {
        console.error('Failed to update status:', result.message);
      }
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const updateStatusclose = async (id) => {
    try {
      const response = await fetch(`http://localhost:4000/closeupdate/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      const result = await response.json();
      console.log("id is the", id)
      if (result.success) {
        // Update the local state to reflect the new status
        console.log("data updated successfully");
      } else {
        console.error('Failed to update status:', result.message);
      }
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const updateStatuscancel = async (id) => {
    try {
      const response = await fetch(`http://localhost:4000/cancel/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      const result = await response.json();
      console.log("id is the", id)
      if (result.success) {
        // Update the local state to reflect the new status
        console.log("data updated successfully");
      } else {
        console.error('Failed to update status:', result.message);
      }
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  useEffect(() => {
    fetchProject(Api);
  }, []);

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const filteredUsers = users.filter((user) =>
    user.ProjectName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.Reason.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.Category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.StartDate.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Pagination logic
  const offset = currentPage * usersPerPage;
  const currentPageUsers = filteredUsers.slice(offset, offset + usersPerPage);
  const pageCount = Math.ceil(filteredUsers.length / usersPerPage);

  const handlePageClick = (event) => {
    setCurrentPage(event.selected);
  };

  return (
    <div className="container-fluid">
      <div style={{ left: "0px", position: "absolute" }}>
        <DashboardHeader />
      </div>
      <div className='container'>
        <div className="row">
          <div className="col-12">
            <div className="project-listing-header">
              <h1>Project Listing</h1>
              <img src={Logo} alt="Company Logo" width="100px" style={{marginLeft: "25%"}}/>
            </div>

            <div className='boxshadow'>
              <div className='d-flex' style={{ width: "40%", backgroundColor: "white", padding: "5px", borderRadius: "5px" }}>
                <input
                  type="text"
                  className="search-input"
                  placeholder="Search"
                  value={searchTerm}
                  onChange={handleSearchChange}
                  style={{ width: "100%", border: "0px", padding: "10px"}}
                />
                <button style={{backgroundColor: "white", border: "0px"}}>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-search" viewBox="0 0 16 16">
                    <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0" />
                  </svg>
                </button>
              </div>

              <div className="table-responsive table-responsive-sm mt-3" style={{borderRadius: "10px"}}>
                <table className="table shadow-lg">
                  <thead>
                    <tr style={{backgroundColor: "#ccf2ff"}}>
                      <th style={{backgroundColor: "#ccf2ff"}} scope="col">Project Name</th>
                      <th style={{backgroundColor: "#ccf2ff"}} scope="col">Reason</th>
                      <th style={{backgroundColor: "#ccf2ff"}} scope="col">Type</th>
                      <th style={{backgroundColor: "#ccf2ff"}} scope="col">Division</th>
                      <th style={{backgroundColor: "#ccf2ff"}} scope="col">Category</th>
                      <th style={{backgroundColor: "#ccf2ff"}} scope="col">Priority</th>
                      <th style={{backgroundColor: "#ccf2ff"}} scope="col">Dept.</th>
                      <th style={{backgroundColor: "#ccf2ff"}} scope="col">Location</th>
                      <th style={{backgroundColor: "#ccf2ff"}} scope="col">Status</th>
                      <th style={{backgroundColor: "#ccf2ff"}} scope="col">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {currentPageUsers.map((curnew, index) => (
                      <tr key={index}>
                        <td>{curnew.ProjectName}</td>
                        <td>{curnew.Reason}</td>
                        <td>{curnew.type}</td>
                        <td>{curnew.Division}</td>
                        <td>{curnew.Category}</td>
                        <td>{curnew.Priority}</td>
                        <td>{curnew.Department}</td>
                        <td>{curnew.Location}</td>
                        <td>{curnew.Status}</td>
                        <td>
                          <button type="button" className='startbutton' onClick={() => updateStatus(curnew._id)}>Start</button>
                          <button type="button" className='Close' onClick={() => updateStatusclose(curnew._id)}>Close</button>
                          <button type="button" className='Cancel' onClick={() => updateStatuscancel(curnew._id)}>Cancel</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="pagination-container">
                <ReactPaginate
                  previousLabel={'Previous'}
                  nextLabel={'Next'}
                  breakLabel={'...'}
                  pageCount={pageCount}
                  marginPagesDisplayed={2}
                  pageRangeDisplayed={3}
                  onPageChange={handlePageClick}
                  containerClassName={'pagination'}
                  pageClassName={'page-item'}
                  pageLinkClassName={'page-link'}
                  previousClassName={'page-item'}
                  previousLinkClassName={'page-link'}
                  nextClassName={'page-item'}
                  nextLinkClassName={'page-link'}
                  breakClassName={'page-item'}
                  breakLinkClassName={'page-link'}
                  activeClassName={'active'}
                />
              </div>

            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default Read;
