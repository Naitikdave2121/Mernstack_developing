import React from 'react';
import create from './Images/createproject.svg';
import { Link } from 'react-router-dom';
import './dashboard.css';
import table from './Images/projectlist.svg';
import dashboard from './Images/dashboard.svg';
import logout from './Images/logout.svg';

const DashboardHeader = () => {
  return (
    <div className="dashboard-header">
      <div className="icon-group">
        <div className="icon-container">
          <Link to="/Dash">
            <img src={dashboard} alt="Dashboard" className="icon" />
          </Link>
        </div>
        <div className="icon-container">
          <Link to="/getdata">
            <img src={table} alt="Table" className="icon" />
          </Link>
        </div>
        <div className="icon-container">
          <Link to="/insertpage">
            <img src={create} alt="Create" className="icon" />
          </Link>
        </div>
    
      <div className="icon-container">
        <Link to="/">
          <img src={logout} alt="Logout" className="icon"/>
        </Link>
      </div>
      </div>  
    </div>
  );
};

export default DashboardHeader;
