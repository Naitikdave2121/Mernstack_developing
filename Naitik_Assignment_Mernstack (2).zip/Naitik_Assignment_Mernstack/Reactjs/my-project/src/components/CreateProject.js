import React, { useState } from 'react';
import axios from 'axios';
import Logo from './Logo.svg';
import './Create.css';
import DashboardHeader from './DashboardHeader';

const Create = () => {
  const [projectTheme, setProjectTheme] = useState('');
  const [reason, setProjectReason] = useState('For Business');
  const [category, setProjectCategory] = useState('Quality A');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [type, setType] = useState('Internal');
  const [priority, setPriority] = useState('High');
  const [division, setDivision] = useState('Filters');
  const [department, setDepartment] = useState('Strategy');
  const [location, setLocation] = useState('Pune');
  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState('');

  const validate = () => {
    const newErrors = {};

    if (!projectTheme) newErrors.projectTheme = 'Please enter project theme';
    if (!startDate) newErrors.startDate = 'Please enter start date';
    if (!endDate) newErrors.endDate = 'Please enter end date';
    if (endDate && startDate && new Date(endDate) < new Date(startDate)) {
      newErrors.endDate = 'End date cannot be earlier than start date';
    }
    if (!type) newErrors.type = 'Please select type';
    if (!priority) newErrors.priority = 'Please select priority';
    if (!division) newErrors.division = 'Please select division';
    if (!department) newErrors.department = 'Please select department';
    if (!location) newErrors.location = 'Please select location';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) {
      return;
    }

    const projectData = {
      ProjectName: projectTheme,
      Reason: reason,
      Category: category,
      StartDate: startDate,
      EndDate: endDate,
      type: type,
      Priority: priority,
      Division: division,
      Department: department,
      Location: location
    };

    console.log('Submitting form with data:', projectData);

    try {
      const response = await axios.post('http://localhost:4000/postdata', projectData);
      console.log('Form submitted successfully:', response.data);
      setSuccessMessage('Project has been added successfully!');
      // Optionally, reset the form fields
      setProjectTheme('');
      setProjectReason('For Business');
      setProjectCategory('Quality A');
      setStartDate('');
      setEndDate('');
      setType('Internal');
      setPriority('High');
      setDivision('Filters');
      setDepartment('Strategy');
      setLocation('Pune');
      setErrors({});
    } catch (error) {
      console.error('Error submitting form:', error);
    }
  };

  return (
    <div className="main-container">
      <DashboardHeader />
      <div className="create-project-container container">
        <div className="header">
          <div className="back-button">
            {/* Back button functionality if needed */}
          </div>
          <div className="flex">
            <h1 style={{ color: "white", padding: "20px" }}>Create Project</h1>
            <img src={Logo} alt="Company Logo" width="100px" style={{ marginLeft: "25%" }} />
          </div>
        </div>
        <form onSubmit={handleSubmit} className="form">
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <div className="form-group">
              <label htmlFor="projectTheme">Enter Project Theme</label>
              <div className="flex">
                <input
                  type="text"
                  className="form-control"
                  id="projectTheme"
                  value={projectTheme}
                  onChange={(e) => setProjectTheme(e.target.value)}
                  style={{ width: '350px' }} // Adjust width as needed
                />
                {errors.projectTheme && <div className="error">{errors.projectTheme}</div>}
              </div>
            </div>
              <input type='submit' className='sub' />
            {/* </div> */}
          </div>
          <div className="form-row">
            <div className="form-group col-md-3">
              <label htmlFor="reason">Reason</label>
              <select
                className="form-control"
                id="reason"
                value={reason}
                onChange={(e) => setProjectReason(e.target.value)}
              >
                <option value="For Business">For Business</option>
                <option value="for trip">For Trip</option>
                <option value="for ERP">For ERP</option>
              </select>
            </div>
            <div className="form-group col-md-3">
              <label htmlFor="category">Category</label>
              <select
                className="form-control"
                id="category"
                value={category}
                onChange={(e) => setProjectCategory(e.target.value)}
              >
                <option value="Quality A">Quality A</option>
                <option value="Quality B">Quality B</option>
                <option value="Quality C">Quality C</option>
              </select>
            </div>
            <div className="form-group col-md-3">
              <label htmlFor="startDate">Start Date as per Project Plan</label>
              <input
                type="date"
                className="form-control"
                id="startDate"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
              {errors.startDate && <div className="error">{errors.startDate}</div>}
            </div>
            <div className="form-group col-md-3">
              <label htmlFor="endDate">End Date as per Project Plan</label>
              <input
                type="date"
                className="form-control"
                id="endDate"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
              {errors.endDate && <div className="error">{errors.endDate}</div>}
            </div>
          </div>
          <div className="form-row">
            <div className="form-group col-md-3">
              <label htmlFor="type">Type</label>
              <select
                className="form-control"
                id="type"
                value={type}
                onChange={(e) => setType(e.target.value)}
              >
                <option value="Internal">Internal</option>
                <option value="External">External</option>
                <option value="cp">cp</option>
              </select>
              {errors.type && <div className="error">{errors.type}</div>}
            </div>
            <div className="form-group col-md-3">
              <label htmlFor="priority">Priority</label>
              <select
                className="form-control"
                id="priority"
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
              >
                <option value="High">High</option>
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
              </select>
              {errors.priority && <div className="error">{errors.priority}</div>}
            </div>
            <div className="form-group col-md-3">
              <label htmlFor="division">Division</label>
              <select
                className="form-control"
                id="division"
                value={division}
                onChange={(e) => setDivision(e.target.value)}
              >
                <option value="Filters">Filters</option>
                <option value="unf">unf</option>
                <option value="uc">uc</option>
              </select>
              {errors.division && <div className="error">{errors.division}</div>}
            </div>
            <div className="form-group col-md-3">
              <label htmlFor="department">Department</label>
              <select
                className="form-control"
                id="department"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
              >
                <option value="Strategy">Strategy</option>
                <option value="IT">IT</option>
                <option value="HR">HR</option>
              </select>
              {errors.department && <div className="error">{errors.department}</div>}
            </div>
          </div>
          <div className="form-row">
            <div className="form-group col-md-3">
              <label htmlFor="location">Location</label>
              <select
                className="form-control"
                id="location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              >
                <option value="Pune">Pune</option>
                <option value="Hyderabad">Hyderabad</option>
                <option value="Chennai">Chennai</option>
              </select>
              {errors.location && <div className="error">{errors.location}</div>}
            </div>
          </div>
          <div className="status-section">
            <p>Status: Registered</p>
            {successMessage && <div className="success-message">{successMessage}</div>}
          </div>
        </form>
      </div>
    </div>
  );
};

export default Create;
