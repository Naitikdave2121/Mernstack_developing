import React, { useState } from 'react';
import './login.css';
import axios from 'axios';
import Logo from './Images/Logo.svg';
import { useNavigate } from 'react-router-dom';
import loginbg from "./Images/loginbg.svg";

const EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

const Login = () => {
  const [Email, setEmail] = useState('davenaitik2@gmail.com');
  const [Password, setPassword] = useState('1234567');
  const [errorMessage, setErrorMessage] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!Email || !Password) {
      if (!Email) {
        setEmailError('Email is mandatory');
      } else {
        setEmailError('');
      }

      if (!Password) {
        setPasswordError('Password is mandatory');
      } else {
        setPasswordError('');
      }
      return;
    }

    try {
      const result = await axios.post('http://localhost:4000/login', { Email, Password });
      console.log(result);
      if (result.data === "Success") {
        navigate('/Dash');
      } else {
        setErrorMessage('Incorrect email or password');
      }
    } catch (err) {
      console.log(err);
      setErrorMessage('An error occurred. Please try again.');
    }
  };

  const validateEmail = () => {
    if (!EMAIL_REGEX.test(Email)) {
      setEmailError('Please enter a valid email address');
      return false;
    }
    setEmailError('');
    return true;
  };

  return (
    <div className='relative'>
      <div className='absolute top-0' style={{ width: "100%", height: "100dvh", backgroundColor: "#f1f1f1" }}>
        <img src={loginbg} alt="image is not found" width="100%"></img>
      </div>
      
      <div style={{ position: "fixed", top: "10%", left: "43%", width: "150px"}}>
        <div className='d-flex justify-center flex-column w-fit' style={{alignItems: 'center'}}>
          <div className="w-full d-flex" style={{flexDirection: "column", justifyContent: "center", alignItems: "center"}}>
            <img src={Logo} alt="Company Logo" height="100px" width={"100px"} />
            <p className='text-light' style={{width: "100%", textWrap:"nowrap"}}>online project management</p>
          </div>
          <div  className="login-form-container" style={{backgroundColor: "white"}}>
              <form className="login-form" onSubmit={handleSubmit}>
                <h2 className="login-title">Login to get Started</h2>
                <div className="form-group">
                  <label htmlFor="email">Email</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    className="form-control"
                    placeholder="Enter email"
                    value={Email}
                    onChange={(e) => setEmail(e.target.value)}
                    onBlur={validateEmail}
                  />
                  {emailError && <p className="error-message">{emailError}</p>}
                </div>
                <div className="form-group">
                  <label htmlFor="password">Password</label>
                  <input
                    type="password"
                    id="password"
                    name="Password"
                    className="form-control"
                    placeholder="Enter password"
                    value={Password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  {passwordError && <p className="error-message">{passwordError}</p>}
                </div>
                <div className="form-group text-end">
                  <a href="#" className="forgot-password">
                    Forgot password?
                  </a>
                </div>
                <div className="form-group">
                  <button type="submit" className="btn">
                    Login
                  </button>
                </div>
                {errorMessage && <div className="error-message">{errorMessage}</div>}
              </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
