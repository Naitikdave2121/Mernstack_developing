import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Create from './components/CreateProject';
import Read from './components/Read_Data';
import Login from './components/Login';
import DashboardHeader from './components/DashboardHeader';
import Dashboard1 from './components/Dashboard1';

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/insertpage" element={<Create />} />
          <Route path="/getdata" element={<Read />} />
          <Route path="/" element={<Login />} />
          <Route path="/dashboard" element={<DashboardHeader />} />
          <Route path="/dash" element={<Dashboard1 />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
